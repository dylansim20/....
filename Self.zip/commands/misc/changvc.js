const { joinVoiceChannel } = require("@discordjs/voice");
var moment = require('moment');
moment.locale("fr-FR")
module.exports = {
    name: "changevc",
    aliases: ['changevc'],
    run: async (message, args, command, client) => {
            let IDChannel = args[0]
            if (!IDChannel) message.reply("désoler tu à oublier l'ID du channel vocal !")
            const Guild = message.guild
            const voiceChannel = Guild.channels.cache.get(IDChannel);
            if(voiceChannel == undefined) {
                message.reply("Désoler l'ID est mauvais")
            } else {
                joinVoiceChannel({
                    channelId: voiceChannel.id,
                    guildId: message.guild.id,
                    adapterCreator: message.guild.voiceAdapterCreator,
                });
            }
    }
}
const { voice, getVoiceConnection } = require("@discordjs/voice");
var moment = require('moment');
moment.locale("fr-FR")
module.exports = {
    name: "test",
    aliases: ['test'],
    run: async (message, args, command, client) => {
        vc = client.utils.get(client.user.voice_clients, guild=message.guild)
        await vc.disconnect()
    }
}
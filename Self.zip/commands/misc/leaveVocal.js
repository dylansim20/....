const { joinVoiceChannel } = require("@discordjs/voice");
var moment = require('moment');
moment.locale("fr-FR")
module.exports = {
    name: "leaveVocal",
    aliases: ['leave'],
    run: async (message, args, command, client) => {
    }
}
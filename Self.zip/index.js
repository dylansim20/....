const { Client, Collection } = require('discord.js-selfbot-v13');
const fs = require('fs');
const config = require('./commands/misc/config.json');
var moment = require('moment');
moment.locale("fr-FR")

const client = new Client({
    checkUpdate: true,
});

const prefix = process.env.PREFIX;
const token = process.env.TOKEN;
client.commands = new Collection();
client.aliases = new Collection();
client.categories = fs.readdirSync("./commands/");


["command"].forEach(handler => {
    require(`./handlers/${handler}`)(client);
});
client.on('ready', (client) => {
    console.log(`${client.user.tag} => ✅`);
})

client.on(`messageCreate`, async message => {
    if (message.author.bot) return;
    if (!message.content.startsWith(prefix)) return;
    if (!message.member) message.member = await message.guild.fetchMember(message);
    const args = message.content.slice(prefix.length).trim().split(/ +/g);
    const cmd = args.shift().toLowerCase();
    if (cmd.length == 0) return;
    let command = client.commands.get(cmd);
    if (!command) command = client.commands.get(client.aliases.get(cmd));
    if (!message.guild) return;

    if (command) command.run(message, args, command, client);
    if (command) { console.log(message.author.tag, "(", message.author.id, `) a éxécuter la commande "${prefix}${command.name}"`) }
})
client.login(token)